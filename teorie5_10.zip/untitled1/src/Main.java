public class Main {
    public static void main(String[] args) {

        Tvor t = new Tvor("Gertruda",21);
        System.out.println("Tvor " + t.getJmeno() + " ma silu " + t.getSila());
        System.out.println("getruda trenuje");
        t.setSila(0);
        System.out.println("Tvor " + t.getJmeno() + " ma silu " + t.getSila());
        Tvor t1 = new Tvor();
        t1.setJmeno("fanda");
        t1.setSila(7);
        System.out.println("Tvor " + t1.getJmeno() + " ma silu " + t1.getSila());
        System.out.println(t.utok(t1));
        Tvor t2 = new Tvor("nadezda","hhhhh");

    }
}