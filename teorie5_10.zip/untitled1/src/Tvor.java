public class Tvor {

    private String jmeno;
    private int sila;
    private String prijmeni;

    public Tvor(String jmeno, int sila){
        this.jmeno = jmeno;
        this.sila = sila;
    }
    public Tvor(String jmeno, String prijmeni){
        this.jmeno = jmeno;
        this.prijmeni = prijmeni;
    }
    public Tvor(int sila){
        this.sila = sila;
    }

    public Tvor(){

    }

    public String utok(Tvor obrance){
        String vysledek = (sila  >=  obrance.sila) ? "Vitezem je " + jmeno : "Vitezem je " + obrance.jmeno;
        return vysledek;
    }

    public void setJmeno(String jm){
        this.jmeno = jm;
    }

    public String getJmeno(){
        return this.jmeno;
    }

    public void setSila(int si){
        this.sila = si;
    }

    public int getSila(){
        return this.sila;
    }


}
